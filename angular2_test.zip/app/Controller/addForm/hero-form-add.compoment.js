"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require('@angular/core');
var router_1 = require('@angular/router');
var firebase_service_1 = require('../../Service/firebase.service');
var HeroFormAddComponent = (function () {
    function HeroFormAddComponent(router, route, _firebaseService) {
        this.router = router;
        this.route = route;
        this._firebaseService = _firebaseService;
        this.models = [];
        this.powers = ['nam', 'nu', 'khong'];
        this.submitted = false;
    }
    HeroFormAddComponent.prototype.ngOnInit = function () {
        var _this = this;
        window.scrollTo(0, 0);
        this.route.params.forEach(function (params) {
            // console.log(params['slug']);
            if (params['slug'] !== 'add') {
                //vao day la edit
                _this.slug = params['slug'];
                _this._firebaseService.getUser(_this.slug)
                    .then(function (response) {
                    _this.models = response;
                });
            }
            else {
                // neu slug = 01 thi lay ra tat ca
                _this._firebaseService.getUser('01')
                    .then(function (response) {
                    _this.models = response;
                });
            }
        });
    };
    HeroFormAddComponent.prototype.onSubmit = function () {
        var _this = this;
        var id = this.models['id'];
        var name = this.models['Name'];
        var Age = this.models['Age'];
        var gioitinh = this.models['gioitinh'];
        if (this.slug !== 'add') {
            var key_id = this.slug;
            this._firebaseService.editUser(key_id, id, name, Age, gioitinh)
                .then(function (response) {
                _this.models = response;
            });
            this.submitted = true;
            this.router.navigate(['/listuser']);
        }
        else {
            this._firebaseService.addUser(id, name, Age, gioitinh)
                .then(function (response) {
                _this.models = response;
            });
            this.submitted = true;
            this.router.navigate(['/newuser/add']);
        }
    };
    HeroFormAddComponent.prototype.generateArray = function (obj) {
        console.log(obj);
        return Object.keys(obj).map(function (key) { return obj[key]; });
    };
    HeroFormAddComponent = __decorate([
        core_1.Component({
            moduleId: module.id,
            selector: 'hero-form-add',
            templateUrl: '../../View/hero-form-add.html',
            providers: [firebase_service_1.FirebaseService]
        }), 
        __metadata('design:paramtypes', [router_1.Router, router_1.ActivatedRoute, firebase_service_1.FirebaseService])
    ], HeroFormAddComponent);
    return HeroFormAddComponent;
}());
exports.HeroFormAddComponent = HeroFormAddComponent;
//# sourceMappingURL=hero-form-add.compoment.js.map