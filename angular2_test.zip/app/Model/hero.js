"use strict";
var Hero = (function () {
    function Hero(id, Name, Age, gioitinh) {
        this.id = id;
        this.Name = Name;
        this.Age = Age;
        this.gioitinh = gioitinh;
    }
    return Hero;
}());
exports.Hero = Hero;
//# sourceMappingURL=hero.js.map