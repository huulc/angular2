export class Hero {
  constructor(
    public id: number,
    public Name: string,
    public Age: number,
    public gioitinh?: string
  ) {  }
}