"use strict";
/**
 * Created by Huulc.
 */
var router_1 = require('@angular/router');
var hero_form_compoment_1 = require('./Controller/hero-form.compoment');
var hero_form_add_compoment_1 = require('./Controller/addForm/hero-form-add.compoment');
var appRoutes = [
    {
        path: 'listuser',
        component: hero_form_compoment_1.HeroFormComponent,
    },
    {
        path: 'newuser/:slug',
        component: hero_form_add_compoment_1.HeroFormAddComponent,
    },
    {
        path: '',
        redirectTo: 'homepage',
        pathMatch: 'full'
    },
];
exports.routing = router_1.RouterModule.forRoot(appRoutes);
//# sourceMappingURL=app.routing.js.map