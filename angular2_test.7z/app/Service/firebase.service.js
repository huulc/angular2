"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require('@angular/core');
var http_1 = require('@angular/http');
require('rxjs/operator/last');
require('rxjs/Rx');
// vì thằng Observable không có toPromise nên phải import hằng operator mà đã extend Observable
require('rxjs/add/operator/toPromise');
var FirebaseService = (function () {
    function FirebaseService(http) {
        this.http = http;
    }
    FirebaseService.prototype.setUser = function (id, name, Age, gioitinh) {
        var body = JSON.stringify({ id: id, Name: name, Age: Age, gioitinh: gioitinh });
        return this.http.put('https://listungvien.firebaseio.com/user.json?auth=Tn5sEzM7t8Lotmy9OqAI8JOElqjX0a8USiF0duhA', body)
            .toPromise()
            .then(function (response) { return response.json(); })
            .catch(this.handleError);
    };
    FirebaseService.prototype.editUser = function (key_id, id, name, Age, gioitinh) {
        var body = JSON.stringify({ id: id, Name: name, Age: Age, gioitinh: gioitinh });
        return this.http.patch('https://listungvien.firebaseio.com/user/' + key_id + '.json?auth=Tn5sEzM7t8Lotmy9OqAI8JOElqjX0a8USiF0duhA', body)
            .toPromise()
            .then(function (response) { return response.json(); })
            .catch(this.handleError);
    };
    FirebaseService.prototype.addUser = function (id, name, Age, gioitinh) {
        var body = JSON.stringify({ id: id, Name: name, Age: Age, gioitinh: gioitinh });
        return this.http.post('https://listungvien.firebaseio.com/user.json?auth=Tn5sEzM7t8Lotmy9OqAI8JOElqjX0a8USiF0duhA', body)
            .toPromise()
            .then(function (response) { return response.json(); })
            .catch(this.handleError);
    };
    FirebaseService.prototype.getUser = function (id) {
        // console.log(id);
        // 01: lay ra all
        if (id == '01') {
            return this.http.get('https://listungvien.firebaseio.com/user.json?auth=Tn5sEzM7t8Lotmy9OqAI8JOElqjX0a8USiF0duhA')
                .toPromise()
                .then(function (response) { return response.json(); })
                .catch(this.handleError);
        }
        else {
            return this.http.get('https://listungvien.firebaseio.com/user/' + id + '.json?auth=Tn5sEzM7t8Lotmy9OqAI8JOElqjX0a8USiF0duhA')
                .toPromise()
                .then(function (response) { return response.json(); })
                .catch(this.handleError);
        }
    };
    FirebaseService.prototype.handleError = function (error) {
        console.error('An error occurred', error);
        return Promise.reject(error.message || error);
    };
    FirebaseService = __decorate([
        core_1.Injectable(), 
        __metadata('design:paramtypes', [http_1.Http])
    ], FirebaseService);
    return FirebaseService;
}());
exports.FirebaseService = FirebaseService;
//# sourceMappingURL=firebase.service.js.map