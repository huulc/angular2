import { Component } from '@angular/core';
import {Router} from '@angular/router';
@Component({
	moduleId: module.id,
  	selector: 'my-app',
  	templateUrl: 'View/layout.html',
})
export class AppComponent  { 
	constructor(public router: Router) {
    }

    gotoHomepage() {
        let anchor = location.hash.replace('#', '');
        this.router.navigate(['listuser'], {fragment: anchor});
    }
}
